package Com.lillyexittest.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import Com.lillyexittest.util.DBConnection;

/**
 * Servlet implementation class InvHistroy
 */
@WebServlet("/InvHistroy")
public class InvHistroy extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InvHistroy() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {

			Connection con = DBConnection.createConnection();
			Statement statement = null;
			ResultSet resultSet = null;
			PreparedStatement ps = null;
			statement = con.createStatement();

			JSONArray arr = new JSONArray();
			JSONObject obj1 = new JSONObject();
			JSONObject obj2 = new JSONObject();
			JSONObject obj4 = new JSONObject();
			JSONObject obj5 = new JSONObject();
			JSONObject obj6 = new JSONObject();

			ArrayList<String> DNo = new ArrayList<String>();
			ArrayList<String> Dname = new ArrayList<String>();
			ArrayList<String> Uid = new ArrayList<String>();
			ArrayList<String> Lid = new ArrayList<String>();
			ArrayList<String> DevDate = new ArrayList<String>();
			ArrayList<String> DevTime = new ArrayList<String>();
			ArrayList<String> DevStatus = new ArrayList<String>();

			ps = con.prepareStatement("select * from InventoryData ORDER BY InventoryData.Inv_Id desc");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				DNo.add(rs.getString("DNo"));
				DevDate.add(rs.getString("Date"));
				Uid.add(rs.getString("U_id"));
				DevTime.add(rs.getString("Time"));
				DevStatus.add(rs.getString("Status"));
			}

			int size = DNo.size();

			for (int i = 0; i < size; i++) {
				ps = con.prepareStatement("select * from DeviceInfo where DNo=?");
				ps.setString(1, DNo.get(i));
				ResultSet rs3 = ps.executeQuery();
				while (rs3.next()) {
					Dname.add(rs3.getString("DeviceName"));

				}

			}

			for (int i = 0; i < size; i++) {
				ps = con.prepareStatement("select * from user_info where U_id=?");
				ps.setString(1, Uid.get(i));
				ResultSet rs3 = ps.executeQuery();
				while (rs3.next()) {
					Lid.add(rs3.getString("L_id"));

				}

			}

			obj1.put("DeviceName", Dname);
			obj1.put("DevDate", DevDate);
			obj1.put("DevTime", DevTime);
			obj1.put("LillyId", Lid);
			obj1.put("DevStatus", DevStatus);

			arr.put(obj1);
			obj2.put("AllDeviceHistory", obj1);
			response.getWriter().write(obj2.toString());
			response.setContentType("application/json");

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
