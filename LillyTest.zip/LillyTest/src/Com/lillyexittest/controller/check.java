package Com.lillyexittest.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import Com.lillyexittest.util.DBConnection;
/**
 * Servlet implementation class check
 */
@WebServlet("/check")
public class check extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public check() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			StringBuilder sb=new StringBuilder();
			BufferedReader br=request.getReader();
			String str=null;
			while ((str = br.readLine()) != null) {
				sb.append(str);
			}
			JSONObject obj=new JSONObject(sb.toString());
			
			String name=obj.getString("Name");
			

			Connection con = DBConnection.createConnection();
			Statement statement = null;
			ResultSet resultSet = null;
			PreparedStatement ps = null;
			PreparedStatement ps1 = null;
			PreparedStatement ps2 = null;
			statement = con.createStatement();

			PrintWriter out = response.getWriter();
			Map Status = new HashMap();

			JSONArray arr = new JSONArray();
			JSONObject obj1 = new JSONObject();
			JSONObject obj2 = new JSONObject();
			JSONObject obj4 = new JSONObject();
			JSONObject obj5 = new JSONObject();
			JSONObject obj6 = new JSONObject();

			ArrayList<String> D_No = new ArrayList<String>();
			ArrayList<String> Device_Name = new ArrayList<String>();
			ArrayList<String> AllDevice_Name = new ArrayList<String>();
			ArrayList<String> Device_Name_Submit = new ArrayList<String>();
			ArrayList<String> User_id = new ArrayList<String>();
			ArrayList<String> AllUserLillid = new ArrayList<String>();
			
			ps = con.prepareStatement("select * from DeviceInfo where Device_Status='Enrolled'");
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				D_No.add(rs.getString("DNo"));
				Device_Name.add(rs.getString("DeviceName"));
				User_id.add(rs.getString("U_id"));
			}
			
			ps = con.prepareStatement("select * from DeviceInfo");
			
			ResultSet rs3 = ps.executeQuery();
			while (rs3.next()) {

				
				AllDevice_Name.add(rs3.getString("DeviceName"));
				
			}
			
			
			ps1 = con.prepareStatement("select * from DeviceInfo where Device_Status='Submit'");
			
			ResultSet rs1 = ps1.executeQuery();
			while (rs1.next()) {
				Device_Name_Submit.add(rs1.getString("DeviceName"));
			}
			
		ps2 = con.prepareStatement("select * from user_info");
			
			ResultSet rs2 = ps2.executeQuery();
			while (rs2.next()) {
				AllUserLillid.add(rs2.getString("L_id"));
			}
			
			
			obj1.put("D_no", D_No);
			obj1.put("DeviceName",Device_Name);
			obj1.put("AllDevice_Name",AllDevice_Name);
			
			obj1.put("Device_Name_Submit",Device_Name_Submit);
			obj1.put("AllUserId",AllUserLillid);
			
			obj1.put("User_id", User_id);
		
			arr.put(obj1);
			obj2.put("items", obj1);
			
			response.getWriter().write(obj2.toString());
			response.setContentType("application/json");
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
	}

}
