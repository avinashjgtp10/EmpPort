package Com.lillyexittest.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import Com.lillyexittest.util.DBConnection;

/**
 * Servlet implementation class InvenInfo
 */
@WebServlet("/InvenInfo")
public class InvenInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InvenInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {

			StringBuilder sb = new StringBuilder();
			BufferedReader br = request.getReader();
			String str = null;
			while ((str = br.readLine()) != null) {
				sb.append(str);
			}

			JSONObject jo = new JSONObject(sb.toString());

			String DeviceName = jo.getString("DeviceName");
			String UserId = jo.getString("User_Id");
			String DeviceDate = jo.getString("GDate");
			String DeviceTime = jo.getString("GTime");
			String Status = jo.getString("Status");

			String msg = null;

			Connection con = DBConnection.createConnection();
			Statement statement = null;
			ResultSet resultSet = null;
			PreparedStatement ps = null;
			statement = con.createStatement();

			PrintWriter out = response.getWriter();

			JSONArray arr = new JSONArray();
			JSONObject obj1 = new JSONObject();
			JSONObject obj2 = new JSONObject();
			JSONObject obj4 = new JSONObject();
			JSONObject obj5 = new JSONObject();
			JSONObject obj6 = new JSONObject();

			String D_num = null;
			String U_num = null;

			ArrayList<String> D_no = new ArrayList<String>();
			ArrayList<String> D_name = new ArrayList<String>();
			ArrayList<String> U_No = new ArrayList<String>();
			ArrayList<String> GDate = new ArrayList<String>();
			ArrayList<String> Time = new ArrayList<String>();
			ArrayList<String> DStatus = new ArrayList<String>();

			ps = con.prepareStatement("select DNO from DeviceInfo where DeviceName=?");
			ps.setString(1, DeviceName);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				D_num = rs.getString("DNO");

			}

			ps = con.prepareStatement("select U_id from user_info where L_id=?");
			ps.setString(1, UserId);
			ResultSet rs1 = ps.executeQuery();
			while (rs1.next()) {
				U_num = rs1.getString("U_id");

			}

			if (D_num != null && U_num != null) {
				//D_no.add(D_num);
				U_No.add(U_num);
				GDate.add(DeviceTime);

				String query = "update DeviceInfo set Device_Status = ? where DNo = ?";
				PreparedStatement preparedStmt = con.prepareStatement(query);
				preparedStmt.setString(1, Status);
				preparedStmt.setString(2, D_num);
				preparedStmt.executeUpdate();

				ps = con.prepareStatement("insert into InventoryData(U_id,DNo,Date,Time,Status) values(?,?,?,?,?)");
				ps.setString(1, U_num);
				ps.setString(2, D_num);
				ps.setString(3, DeviceDate);
				ps.setString(4, DeviceTime);
				ps.setString(5, Status);

				int i = ps.executeUpdate();
				if (i > 0) {

					if (Status.equals("Enrolled")) {
						msg = "Enrolled";
					} else if (Status.equals("Submit")) {
						msg = "Submit";
					} else {
						msg = "error";
					}
				

				}

			}
			
			String d_no = null;
			
			ps = con.prepareStatement("select * from InventoryData where U_id=?");
			ps.setString(1, U_num);
			ResultSet rs2 = ps.executeQuery();
			while (rs2.next()) {
						D_no.add(rs2.getString("DNo"));
						GDate.add(rs2.getString("Date"));
						Time.add(rs2.getString("Time"));
						DStatus.add(rs2.getString("Status"));
						
						
			}
			
			int size=D_no.size();
			
			for(int i=0;i<size;i++){
				ps = con.prepareStatement("select * from DeviceInfo where DNo=?");
				ps.setString(1, D_no.get(i));
				ResultSet rs3 = ps.executeQuery();
				while (rs3.next()) {
					D_name.add(rs3.getString("DeviceName"));
					
				}
				
			}
			obj1.put("Device_Name", D_name);
			obj1.put("Date", GDate);
			obj1.put("Time", Time);
			obj1.put("Status", DStatus);
			obj1.put("Msg", msg);

			arr.put(obj1);
			obj2.put("Ivdata", obj1);
			response.getWriter().write(obj2.toString());
			response.setContentType("application/json");

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
