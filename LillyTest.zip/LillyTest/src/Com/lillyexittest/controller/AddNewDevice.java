package Com.lillyexittest.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import Com.lillyexittest.util.DBConnection;

/**
 * Servlet implementation class AddNewDevice
 */
@WebServlet("/AddNewDevice")
public class AddNewDevice extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddNewDevice() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {

			StringBuilder sb = new StringBuilder();
			BufferedReader br = request.getReader();
			String str = null;
			while ((str = br.readLine()) != null) {
				sb.append(str);
			}
			JSONObject jObj = new JSONObject(sb.toString());

			String DeviceNo = jObj.getString("DeviceNo");
			String LId = jObj.getString("LillyId");
			String Dtype=jObj.getString("DeviceType");
			String Dversion=jObj.getString("DeviceOS");
			String Dmodel=jObj.getString("DeviceModel");
			String DIMEI=jObj.getString("DeviceIMEI");
			String Dserail=jObj.getString("DeviceSerial");
			String DStatus=jObj.getString("Status");

			Connection con = DBConnection.createConnection();
			Statement statement = null;
			ResultSet resultSet = null;
			PreparedStatement ps = null;
			PreparedStatement ps1 = null;
			statement = con.createStatement();

			PrintWriter out = response.getWriter();
			Map Status = new HashMap();

			JSONArray arr = new JSONArray();
			JSONObject obj1 = new JSONObject();
			JSONObject obj2 = new JSONObject();
			JSONObject obj4 = new JSONObject();
			JSONObject obj5 = new JSONObject();
			JSONObject obj6 = new JSONObject();

			ArrayList<String> Message = new ArrayList<String>();
			ArrayList<String> LillyId = new ArrayList<String>();
			ArrayList<String> Access = new ArrayList<String>();

			String Dn = null, msg = null;
			String li = null;
			ps = con.prepareStatement("select * from DeviceInfo where DeviceName=?");
			ps.setString(1, DeviceNo);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Dn = rs.getString("DeviceName");
			}
			if (DeviceNo.equals(Dn)) {
				Message.add("Already");
			} else {

				ps1 = con.prepareStatement("select * from user_info where L_id=?");
				ps1.setString(1, LId);

				ResultSet rs1 = ps1.executeQuery();
				while (rs1.next()) {
					li = rs1.getString("U_id");
				}

				ps = con.prepareStatement("insert into DeviceInfo(DeviceName,U_id,Device_Status,Device_Type,Device_OS,Device_Model,Device_IMEI,Device_SerialNo) values(?,?,?,?,?,?,?,?)");
				ps.setString(1, DeviceNo);
				ps.setString(2, li);
				ps.setString(3, DStatus);
				ps.setString(4, Dtype);
				ps.setString(5, Dversion);
				ps.setString(6, Dmodel);
				ps.setString(7, DIMEI);
				ps.setString(8, Dserail);
				
				int i = ps.executeUpdate();

				if (i > 0) {
					Message.add("Device is inserted");
				} else {
					Message.add("Device is not inserted");
				}
			}

			obj1.put("Message", Message);
			//obj1.put("LillyId", LillyId);
			arr.put(obj1);
			obj2.put("items", obj1);
			response.getWriter().write(obj2.toString());
			response.setContentType("application/json");

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
