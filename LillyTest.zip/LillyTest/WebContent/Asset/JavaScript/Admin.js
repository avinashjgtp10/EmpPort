var adminApp = angular.module("AdminApp", [ "ngRoute", 'ngCookies',
		'angularUtils.directives.dirPagination', 'oitozero.ngSweetAlert','ngMaterial' ]);

adminApp.config(function($routeProvider) {
	// $locationProvider.html5Mode(true);
	$routeProvider.when("/", {
		templateUrl : "DeviceInfo.jsp"
	}).when("/Inventory", {
		templateUrl : "InventoryInfo.jsp"
	}).when("/Home", {
		templateUrl : "DeviceInfo.jsp"
	}).when("/ExitTest", {
		templateUrl : "TestFile.jsp"
	}).when("/DeviceLocation", {
		templateUrl : "DeviceLocation.jsp"
	}).when("/AdminInventory", {
		templateUrl : "InventoryInfo.jsp"
	}).when("/DeviceDetails", {
		templateUrl : "DeviceDetails.jsp"
	}).when("/AddDevice", {
		templateUrl : "AddDevice.jsp"
	}).otherwise({
		templateUrl : "DeviceInfo.jsp"
	});

});

adminApp
		.controller(
				"AdminCtrl",
				function($scope, $http, $timeout, $interval, $location,
						$cookieStore, $route, SweetAlert) {
					
					
					
					
					$scope.DivVisiblity = true;
					$scope.QueVisiblity = false;

					$scope.EmpOption = true;
					$scope.CheckPaper = false;

					$scope.ValJson = [];
					$scope.opt1 = [];
					$scope.count = 0;
					$scope.v = [];
					$scope.a = 0;
					$scope.AdminName = null;

					$scope.Submit = function() {
						$scope.QueVal = angular.element('#search').val();
						if ($scope.QueVal !== "ExamOver") {
							$http(
									{
										method : "POST",
										url : 'QuestionAnswer',
										data : {
											'Answer' : $scope.Answer,
											'UserId' : $scope.paperId,
											'Question' : angular.element(
													'#search').val(),
										}
									}).then(function success(response) {
								$scope.AnswerSubmit = response.data;

							});
						} else {
							$scope.DivVisiblity = true;
							$scope.QueVisiblity = false;
						}
					};

					/* UserLogin */
					$scope.insertData = function() {
						$http({
							method : "POST",
							url : 'log',
							dataType : 'json',
							data : {
								'UserName' : $scope.UserName,
								'Password' : $scope.Password,
							}
						})
								.then(
										function success(response) {
											console.log(response.data.items);
											$scope.Access = response.data.items.Access;
											$scope.UserLillyId = response.data.items.LillyId;
											$scope.UserLillyName = response.data.items.UserName;

											$cookieStore.put("UserLillyId",
													$scope.UserLillyId[0]);
											$cookieStore.put("UserName",
													$scope.UserLillyName[0]);

											if ($scope.Access == "Admin") {
												window.open("Admin.jsp",
														"_self");
												$scope.AdminName = response.data.items.UserName;
											} else if ($scope.Access == "User") {
												window.open("HomePage.jsp",
														"_self");
												$scope.AdminName = response.data.items.UserName;
												alert($scope.Access);
											} else {
												alert("Error");
											}

										});

					};

					$scope.UserCookieLid = $cookieStore.get('UserLillyId');

					/* UserLogin End */

					var re = [];

					$scope.aname = {
						model : null,
						avilOption : [

						{
							id : '129',
							name : 'Check'
						}, {
							id : '141',
							name : 'Chetna'
						}, {
							id : '138',
							name : 'Ravindra'
						}, {
							id : '140',
							name : 'Neha'
						}, {
							id : '141',
							name : 'Ankush'
						} ]
					}

					$scope.Check = function() {
						$scope.uid = $scope.aname.model;

						if ($scope.uid != null) {
							$scope.CheckPaper = true;

							$http({
								method : "POST",
								url : 'CheckServlet',
								dataType : 'json',
								data : {
									'Uid' : $scope.uid,
								}
							})
									.then(
											function success(response) {

												$scope.results = [];
												$scope.results
														.push(response.data.items);
												console
														.log(response.data.items);
												$scope.User_Id = response.data.items.User_Id[0];
												$scope.ans = response.data.items.Answer;
												$scope.que = response.data.items.Question;
												$scope.Sum = response.data.items.Sum;
												$scope.Count = response.data.items.Count;
												$scope.Quesde = response.data.items.Question[0];
												$scope.AnsDe = response.data.items.Answer[1];

											});
						} else {
							alert("Please select name");
						}

					};

					$scope.count = 0;
					$scope.AnsSubmit = function() {
						var mar = document.getElementById("Mark").value;
						var Question = document.getElementById("Ques").value;
						$scope.mark = mar;
						$scope.count++;

						if ($scope.Quesde == null) {

							alert($scope.Sum + " " + $scope.Count);
							$scope.CheckPaper = false;

						} else if (typeof mar !== "undefined" && mar !== null) {
							console.log(Question + " " + mar + " "
									+ $scope.User_Id);
							$http({
								method : "POST",
								url : 'SubmitMark',
								data : {
									'Question' : Question,
									'Mark' : mar,
									'UserId' : $scope.User_Id,
								}
							})
									.then(
											function success(response) {
												console.log(response.data);
												if (response.data == "Error") {
													$scope.alertDisplay = "Error";
												} else {
													$scope.resMsg = "Marks has been updated successfully";
													document
															.getElementById("Mark").value = "";
												}

											});
							$scope.Quesde = $scope.que[$scope.count];
							$scope.AnsDe = $scope.ans[$scope.count + 1];

							$scope.alertDisplay = true;
							$timeout(function() {
								$scope.alertDisplay = false;
							}, 2000);

						} else {
							alert("Please Enter marks");
						}

					};

					/* User Register */

					$scope.deviceType = {
						model : null,
						avilOption : [ {
							id : 'N/A',
							name : 'N/A'
						}, {
							id : 'iPad',
							name : 'iPad'
						}, {
							id : 'iPhone',
							name : 'iPhone'
						}, {
							id : 'Android',
							name : 'Android'
						} ]
					}

					$scope.ValChange = function() {
						document.getElementById("deviceDetail").disabled = true;
						if ($scope.deviceType.model === "N/A") {
							document.getElementById("deviceDetail").disabled = true;
							$scope.DeviceDet = "N/A"

						} else {
							document.getElementById("deviceDetail").disabled = false;
							document.getElementById("deviceDetail").value = "";
						}
					};

					$scope.UserRegister = function() {
						$scope.DeviceType = $scope.deviceType.model;

						if (typeof $scope.name === "undefined") {
							$scope.alertMsg = "Please Enter your name";

						} else if (typeof $scope.LillyId === "undefined") {

							$scope.alertMsg = "Please Enter your Lilly Id";
						} else if (typeof $scope.Password === "undefined") {
							$scope.alertMsg = "Please Enter password";
						} else if (typeof $scope.DeviceDet === "undefined") {
							$scope.alertMsg = "Please enter device number";

						} else {
							$http({
								method : "POST",
								url : 'UserRegister',
								data : {
									'LillyId' : $scope.LillyId,
									'Name' : $scope.name,
									'Password' : $scope.Password,
									'DeviceType' : $scope.DeviceType,
									'DeviceNo' : $scope.DeviceDet,
									'Status' : "Unapproved",
								}
							})
									.then(
											function success(response) {
												console.log(response.data);
												if (response.data == "Successs") {
													$scope.alertMsg = "Your account has been successfully registered.";

												}
											});
						}

					};

					// Get Device information and store in db

					Date.prototype.getMonthText = function() {
						var months = [ 'January', 'February', 'March', 'April',
								'May', 'June', 'July', 'August', 'September',
								'October', 'November', 'December' ];
						return months[this.getMonth()];
					};

					$scope.GetForm = {};

					$scope.TickDate = function() {
						$scope.date = new Date();
						$scope.getdate = $scope.date.getDate();
						$scope.getmonth = $scope.date.getMonthText();
						$scope.getyear = $scope.date.getFullYear();

						if ($scope.getdate < 10) {
							$scope.getdate = "0" + $scope.getdate;
						}
						if ($scope.getmonth < 10) {
							$scope.getmonth = "0" + $scope.getmonth;
						}

						$scope.GetDate = $scope.getdate + " " + $scope.getmonth
								+ " " + $scope.getyear;
						return $scope.GetDate;
					};

					$scope.TickTime = function() {
						$scope.date = new Date();
						$scope.hour = $scope.date.getHours();
						$scope.minute = $scope.date.getMinutes();
						$scope.amPM = ($scope.hour > 11) ? "PM" : "AM";
						if ($scope.hour > 12) {
							$scope.hour -= 12;
						} else if ($scope.hour == 0) {
							$scope.hour = "12";
						}

						if ($scope.hour < 10) {
							$scope.hour = "0" + $scope.hour;
						}
						if ($scope.minute < 10) {
							$scope.minute = "0" + $scope.minute;
						}

						$scope.GetTime = $scope.hour + ":" + $scope.minute
								+ " " + $scope.amPM;
						return $scope.GetTime;
					};

					$scope.GetTime = $scope.TickTime();
					$scope.GetDate = $scope.TickDate();

					$interval(function() {
						$scope.GetTime = $scope.TickTime();
						$scope.GetDate = $scope.TickDate();

					}, 1000);

					$http({
						method : "POST",
						url : 'check',
						data : {

							'Name' : "Demoipad",
						}

					})
							.then(
									function success(response) {
										$scope.data = response.data;

										$scope.AllDeviceName = response.data.items.AllDevice_Name;
										$scope.Dno = response.data.items.D_no;
										$scope.Dname = response.data.items.Device_Name_Submit;
										$scope.Dsname = response.data.items.DeviceName;
										$scope.AllUserLillyId = response.data.items.AllUserId;

									});

					$scope.showSelectValue = function(selectedName) {
						$scope.selectedName = selectedName;
					};

					$scope.GetInfo = function() {

						if (typeof ($scope.selectedName) === "undefined") {
							$scope.Dmsg = "Please select Device type";// alert();
						} else {

							$http({
								method : "POST",
								url : 'InvenInfo',
								data : {

									'DeviceName' : $scope.selectedName,
									'User_Id' : $scope.UserCookieLid,
									'GDate' : $scope.GetDate,
									'GTime' : $scope.GetTime,
									'Status' : "Enrolled"
								}

							})
									.then(
											function success(response) {

												$route.reload();
												console.log(response);

												alert("Device has been enrolled successfully.");

											});

						}

					};

					$scope.Submit_Info = function() {

						if (typeof ($scope.selectedName) === "undefined") {
							alert("Please select Device type");
						} else {

							$http({
								method : "POST",
								url : 'InvenInfo',
								data : {

									'DeviceName' : $scope.selectedName,
									'User_Id' : $scope.UserCookieLid,
									'GDate' : $scope.GetDate,
									'GTime' : $scope.GetTime,
									'Status' : "Submit"
								}

							})
									.then(
											function success(response) {
												$route.reload();
												alert("Device has been submitted successfully.");

											});
						}
					};

					// Perticular User Device Info

					$http({
						method : "POST",
						url : 'PertUserDeviceInfo',
						data : {
							'User_Id' : $scope.UserCookieLid,
						}

					})
							.then(
									function success(response) {

										$scope.Dev = null;
										$scope.DeviceDetails = response.data;
										$scope.length = $scope.DeviceDetails.DeviceDetails.DevStatus.length;
										$scope.DeviceInvData = [];
										for ( var i = 0; i < $scope.length; i++) {
											$scope.DeviceInvData[i] = {
												Dname : $scope.DeviceDetails.DeviceDetails.DeviceName[i],
												DDate : $scope.DeviceDetails.DeviceDetails.DevDate[i],
												DTime : $scope.DeviceDetails.DeviceDetails.DevTime[i],
												DevStatus : $scope.DeviceDetails.DeviceDetails.DevStatus[i]
											};
										}
										;

									});

					$scope.sort = function(keyname) {
						$scope.sortKey = keyname;
						$scope.reverse = !$scope.reverse;
					};
					$scope.Print = function() {
						$scope.pri == document.getElementById("printTable").value;
						newWin = window.open("");
						newWin.document.write($scope.pri.outerHTML);
						newWin.print();
						newWin.close();
					};

					$http({
						method : 'POST',
						url : 'InvHistroy'
					})
							.then(
									function successCallback(response) {
										console.log(response);

										$scope.Dev = null;
										$scope.DeviceDetails = response.data;
										$scope.length = $scope.DeviceDetails.AllDeviceHistory.DevStatus.length;
										console.log($scope.length);
										$scope.DeviceInvHistory = [];

										for ( var i = 0; i < $scope.length; i++) {
											$scope.DeviceInvHistory[i] = {
												Dname : $scope.DeviceDetails.AllDeviceHistory.DeviceName[i],
												DDate : $scope.DeviceDetails.AllDeviceHistory.DevDate[i],
												DTime : $scope.DeviceDetails.AllDeviceHistory.DevTime[i],
												DevStatus : $scope.DeviceDetails.AllDeviceHistory.DevStatus[i],
												LillyId : $scope.DeviceDetails.AllDeviceHistory.LillyId[i],

											};
										}
										;

									}, function errorCallback(response) {

									});

					// *****************************End*********************
					// Register Device information
					$scope.addAddFormVal = {};

					$scope.showSelectLillyId = function(selectedLillyId) {
						$scope.SelLillyId = selectedLillyId;
					};
					$scope.alertAddDevice = false;

					$scope.alertAddDev = function() {
						$scope.alertAddDevice = true;
						$timeout(function() {
							$scope.alertAddDevice = false;
						}, 2000);
					};

					$scope.AddDevice = function() {

						if (typeof ($scope.SelLillyId) == "undefined") {
							$scope.alertAddDev();
							$scope.AddDeviceSelErr = "*Please select user id";
						}
						if (typeof ($scope.addAddFormVal.DevSer) == "undefined") {
							$scope.alertAddDev();
							$scope.AddDeviceDevSerErr = "*Please Enter Device serial Number";
						} else {
							console.log($scope.addAddFormVal.DevType + " "
									+ $scope.addAddFormVal.DevVer + " "
									+ $scope.addAddFormVal.DevIMEI + " "
									+ $scope.addAddFormVal.DevModel + " "
									+ $scope.addAddFormVal.DevSer);

							$http(
									{
										method : "POST",
										url : 'AddNewDevice',
										data : {

											'DeviceNo' : $scope.addAddFormVal.DevNo,
											'LillyId' : $scope.SelLillyId,
											'DeviceType' : $scope.addAddFormVal.DevType,
											'DeviceOS' : $scope.addAddFormVal.DevVer,
											'DeviceModel' : $scope.addAddFormVal.DevModel,
											'DeviceIMEI' : $scope.addAddFormVal.DevIMEI,
											'DeviceSerial' : $scope.addAddFormVal.DevSer,
											'Status' : "Submit"
										}

									})
									.then(
											function success(response) {
												console
														.log(response.data.items.Message);
												if (response.data.items.Message == "Already") {

													$scope.DeviceAlready = $scope.addAddFormVal.DevNo
															+ " is already added in inventory.";
													$scope.alertalReadyDevice = true;
													$timeout(
															function() {
																$scope.alertalReadyDevice = false;
															}, 3000);
												} else {
													alert(response.data.items.Message)
												}

											});

						}
					};
					$scope.UpdateShow = false;

					// $http({
					// method : "GET",
					// dataType : "JSONP",
					// url : 'http://10.30.64.77:8080/listLocations',
					// data : {
					// 'User_Id' : $scope.UserCookieLid,
					// }
					//
					// }).then(function success(response) {
					// console.log(response.data);
					//
					// }, function errorCallback(response) {
					// console.log(response);
					// });

					$scope.showSelectDeviceName = function(selectedDeviceName) {

						$scope.UpdateShow = true;
						$scope.addAddFormVal.DevNumber = selectedDeviceName;

						$http({
							method : "POST",
							url : 'GetDeviceInfo',
							dataType : 'json',
							data : {

								'DeviceNo' : selectedDeviceName
							}

						})
								.then(
										function success(response) {

											$scope.addAddFormVal.DeviceOS = response.data.DeviceDetails.DeviceOS;
											$scope.addAddFormVal.DeviceType = response.data.DeviceDetails.DeviceType;
											$scope.addAddFormVal.DeviceSerial = response.data.DeviceDetails.DeviceSerial;
											$scope.addAddFormVal.DeviceIMEI = response.data.DeviceDetails.DeviceIMEI;
											$scope.addAddFormVal.LillyID = response.data.DeviceDetails.Lilly_ID;
											$scope.addAddFormVal.DeviceModel = response.data.DeviceDetails.DeviceModel;
											$scope.selectedLillyId = $scope.addAddFormVal.LillyID;
										});

						$scope.UpdateDevice = function() {
							console.log($scope.addAddFormVal.DevNumber
									.toString());
							$http(
									{
										method : "POST",
										url : "UpdateDevice",
										data : {
											'DeviceNo' : selectedDeviceName,
											'DeviceName' : $scope.addAddFormVal.DevNumber
													.toString(),
											'UserLillyiD' : $scope.SelLillyId,
											'DeviceType' : $scope.addAddFormVal.DeviceType
													.toString(),
											'DeviceOS' : $scope.addAddFormVal.DeviceOS
													.toString(),
											'DeviceModel' : $scope.addAddFormVal.DeviceOS
													.toString(),
											'DeviceIMEI' : $scope.addAddFormVal.DeviceIMEI
													.toString(),
											'DeviceSerial' : $scope.addAddFormVal.DeviceSerial
													.toString(),

										}

									}).then(function success(response) {

								console.log(response);

								alert(response.data.UpdateData.Message);
							});

						};

					};

					// Remove Device information
					$scope.showRemoveDeviceName = function(RemoveDeviceName) {
						$scope.RemoveDeviceName = RemoveDeviceName;
						$scope.con = confirm("Are you sure you want to delete "
								+ RemoveDeviceName + " ?");
						if ($scope.con == true) {

							$http({
								method : "POST",
								url : "RemoveDevice",
								data : {
									"DeviceNo" : RemoveDeviceName,
								}

							}).then(function success(response) {

								alert(response.data.Deleteinfo.Message);
								$route.reload();
								// console.log(response);
							});

						}

					};

					// Map
					

				});
